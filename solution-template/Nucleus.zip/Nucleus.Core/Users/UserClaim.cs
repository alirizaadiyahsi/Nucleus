﻿using System;
using Microsoft.AspNetCore.Identity;

namespace $safeprojectname$.Users
{
    public class UserClaim : IdentityUserClaim<Guid>
    {
    }
}
