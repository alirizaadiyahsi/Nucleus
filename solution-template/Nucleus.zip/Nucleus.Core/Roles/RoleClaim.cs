﻿using System;
using Microsoft.AspNetCore.Identity;

namespace $safeprojectname$.Roles
{
    public class RoleClaim : IdentityRoleClaim<Guid>
    {

    }
}