﻿using Microsoft.AspNetCore.Mvc;
using Nucleus.Web.Core.Controllers;

namespace $safeprojectname$.Controller.Test
{
    public class TestController : BaseController
    {
        [HttpGet("[action]")]
        public ObjectResult Get(string userNameOrEmail)
        {
            return Ok(new { TestMessage = "Test success!" });
        }
    }
}