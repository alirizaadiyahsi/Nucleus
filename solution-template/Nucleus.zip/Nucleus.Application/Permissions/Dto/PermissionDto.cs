﻿using $safeprojectname$.Dto;

namespace $safeprojectname$.Permissions.Dto
{
    public class PermissionDto : EntityDto
    {
        public string Name { get; set; }

        public string DisplayName { get; set; }
    }
}