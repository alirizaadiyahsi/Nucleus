﻿using System;

namespace $safeprojectname$.Dto
{
    public class PagedListOutput
    {
        public Guid Id { get; set; }
    }
}