﻿namespace $safeprojectname$.Dto.Account
{
    public class ForgotPasswordOutput
    {
        public string ResetToken { get; set; }
    }
}