﻿namespace $safeprojectname$.Dto.Account
{
    public class LoginOutput
    {
        public string Token { get; set; }
    }
}
