﻿namespace $safeprojectname$.Dto.Account
{
    public class ForgotPasswordInput
    {
        public string UserNameOrEmail { get; set; }
    }
}