﻿using System;

namespace $safeprojectname$.Dto
{
    public class EntityDto
    {
        public Guid Id { get; set; }
    }
}
