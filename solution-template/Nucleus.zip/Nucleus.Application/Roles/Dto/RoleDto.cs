﻿using $safeprojectname$.Dto;

namespace $safeprojectname$.Roles.Dto
{
    public class RoleDto : EntityDto
    {
        public string Name { get; set; }
    }
}