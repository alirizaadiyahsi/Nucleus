﻿using $safeprojectname$.Dto;

namespace $safeprojectname$.Roles.Dto
{
    public class RoleListInput : PagedListInput
    {
        public RoleListInput()
        {
            SortBy = "Name";
        }
    }
}