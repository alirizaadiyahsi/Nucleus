﻿using $safeprojectname$.Dto;

namespace $safeprojectname$.Roles.Dto
{
    public class GetRoleForCreateOrUpdateInput : EntityDto
    {
    }
}