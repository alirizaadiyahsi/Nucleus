﻿using $safeprojectname$.Dto;

namespace $safeprojectname$.Roles.Dto
{
    public class RoleListOutput : PagedListOutput
    {
        public string Name { get; set; }

        public bool IsSystemDefault { get; set; }
    }
}