﻿using $safeprojectname$.Dto;

namespace $safeprojectname$.Users.Dto
{
    public class UserListInput : PagedListInput
    {
        public UserListInput()
        {
            SortBy = "UserName";
        }
    }
}