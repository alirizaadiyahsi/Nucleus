﻿using $safeprojectname$.Dto;

namespace $safeprojectname$.Users.Dto
{
    public class UserListOutput : PagedListOutput
    {
        public string UserName { get; set; }

        public string Email { get; set; }
    }
}