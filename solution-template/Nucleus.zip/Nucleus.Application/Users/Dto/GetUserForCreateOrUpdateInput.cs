﻿using $safeprojectname$.Dto;

namespace $safeprojectname$.Users.Dto
{
    public class GetUserForCreateOrUpdateInput : EntityDto
    {
    }
}