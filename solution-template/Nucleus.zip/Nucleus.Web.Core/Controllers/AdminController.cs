﻿using Microsoft.AspNetCore.Authorization;
using Nucleus.Core.Permissions;

namespace $safeprojectname$.Controllers
{
    [Authorize(Policy = DefaultPermissions.PermissionNameForAdministration)]
    public class AdminController : BaseController
    {

    }
}