﻿using Microsoft.AspNetCore.Authorization;
using Nucleus.Core.Permissions;

namespace $safeprojectname$.Controllers
{
    [Authorize(Policy = DefaultPermissions.PermissionNameForMemberAccess)]
    public class AuthorizedController : BaseController
    {

    }
}