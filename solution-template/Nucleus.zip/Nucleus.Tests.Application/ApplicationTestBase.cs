﻿using Nucleus.Tests.Shared;

namespace $safeprojectname$
{
    public class ApplicationTestBase : TestBase
    {

    }
}
