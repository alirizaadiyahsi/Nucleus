import { __decorate } from "tslib";
import NucleusComponentBase from '@/shared/application/nucleus-component-base';
import { Component } from 'vue-property-decorator';
let HomeComponent = class HomeComponent extends NucleusComponentBase {
};
HomeComponent = __decorate([
    Component
], HomeComponent);
export default HomeComponent;
//# sourceMappingURL=home.js.map