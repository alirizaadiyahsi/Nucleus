import NucleusComponentBase from '@/shared/application/nucleus-component-base';
import { Component } from 'vue-property-decorator';

@Component
export default class HomeComponent extends NucleusComponentBase {
    // TODO: Add example components
}