﻿<template>
    <div>
        Welcome to Nucleus!
    </div>
</template>

<script src="./home.ts"></script>