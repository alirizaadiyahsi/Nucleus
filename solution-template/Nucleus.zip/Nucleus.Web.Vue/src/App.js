import { __decorate } from "tslib";
import NucleusComponentBase from '@/shared/application/nucleus-component-base';
import { Component } from 'vue-property-decorator';
let AppComponent = class AppComponent extends NucleusComponentBase {
};
AppComponent = __decorate([
    Component
], AppComponent);
export default AppComponent;
//# sourceMappingURL=App.js.map