﻿interface IResetPasswordOutput {
}