﻿interface IForgotPasswordOutput {
}