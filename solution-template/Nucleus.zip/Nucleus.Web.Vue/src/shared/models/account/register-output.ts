﻿interface IRegisterOutput {
    resultMessage: string;
}