﻿interface IChangePasswordOutput {

}