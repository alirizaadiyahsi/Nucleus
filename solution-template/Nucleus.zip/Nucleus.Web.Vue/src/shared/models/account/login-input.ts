﻿interface ILoginInput {
    userNameOrEmail: string;
    password: string;
}