﻿interface IChangePasswordInput {
    currentPassword: string;
    newPassword: string;
    passwordRepeat: string;
}