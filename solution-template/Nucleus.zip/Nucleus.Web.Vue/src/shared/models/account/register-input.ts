﻿interface IRegisterInput {
    userName: string;
    email: string;
    password: string;
    passwordRepeat: string;
}