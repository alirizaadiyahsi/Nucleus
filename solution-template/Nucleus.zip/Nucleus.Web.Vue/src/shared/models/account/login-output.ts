﻿interface ILoginOutput {
    token: string;
}