﻿interface IForgotPasswordInput {
    userNameOrEmail: string;
}