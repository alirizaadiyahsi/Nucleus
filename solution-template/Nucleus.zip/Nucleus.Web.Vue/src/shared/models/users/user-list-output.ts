﻿interface IUserListOutput {
    userName: string;
    email: string;
}