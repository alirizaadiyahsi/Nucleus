﻿interface IUserDto extends IEntityDto {
    userName: string;
    email: string;
    password: string;
    passwordRepeat: string;
}