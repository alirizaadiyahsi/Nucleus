﻿interface IRoleListOutput {
    name: string;
    isSystemDefault: boolean;
}