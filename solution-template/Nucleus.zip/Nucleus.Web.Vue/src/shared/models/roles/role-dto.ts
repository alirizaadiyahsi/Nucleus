﻿interface IRoleDto extends IEntityDto {
    name: string;
}