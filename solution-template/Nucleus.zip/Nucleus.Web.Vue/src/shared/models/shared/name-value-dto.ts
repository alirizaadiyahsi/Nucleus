﻿interface INameValueDto {
    name: string;
    value: string;
}