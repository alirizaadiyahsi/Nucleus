﻿interface IEntityDto {
    id?: string;
}