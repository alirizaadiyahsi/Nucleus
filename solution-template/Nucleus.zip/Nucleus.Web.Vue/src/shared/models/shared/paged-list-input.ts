﻿interface IPagedListInput {
    filter?: string;
    sortBy?: string;
    pageIndex?: number;
    pageSize?: number;
}