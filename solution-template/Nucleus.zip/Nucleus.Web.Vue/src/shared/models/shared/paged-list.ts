﻿interface IPagedList<T> {
    totalCount: number;
    items: T[];
}