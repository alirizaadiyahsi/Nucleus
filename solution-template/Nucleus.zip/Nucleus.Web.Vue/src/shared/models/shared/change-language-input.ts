﻿interface ILanguageDto {
    languageCode: string;
    languageName: string;
}