﻿interface IPermissionDto extends IEntityDto {
    name: string;
    displayName: string;
}