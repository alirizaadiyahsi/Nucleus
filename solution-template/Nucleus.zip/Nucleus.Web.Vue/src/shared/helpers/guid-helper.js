export default class Guid {
    static get empty() {
        return '00000000-0000-0000-0000-000000000000';
    }
}
//# sourceMappingURL=guid-helper.js.map